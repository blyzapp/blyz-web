async function joinWaitlist() {
  const email = document.getElementById("emailInput").value.trim();

  if (!email) {
    alert("Please enter an email.");
    return;
  }

  try {
    const res = await fetch("https://your-server.com/api/landing/email", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });

    if (res.ok) {
      alert("You're on the waitlist! Thank you!");
      document.getElementById("emailInput").value = "";
    } else {
      alert("Something went wrong.");
    }
  } catch (err) {
    alert("Server unavailable.");
  }
}
